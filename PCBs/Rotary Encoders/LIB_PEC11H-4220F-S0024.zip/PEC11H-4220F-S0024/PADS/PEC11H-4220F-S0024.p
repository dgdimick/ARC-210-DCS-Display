*PADS-LIBRARY-PART-TYPES-V9*

PEC11H-4220F-S0024 PEC11H4220FS0024 I ANA 7 1 0 0 0
TIMESTAMP 2026.10.12.10.26.19
"Mouser Part Number" 652-PEC11H4220FS0024
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Bourns/PEC11H-4220F-S0024?qs=7MVldsJ5UayW2mw8xYm74g%3D%3D
"Manufacturer_Name" Bourns
"Manufacturer_Part_Number" PEC11H-4220F-S0024
"Description" Encoders ROTARY ENCODER W/BALL SPRING
"Datasheet Link" https://www.bourns.com/docs/Product-Datasheets/PEC11H.pdf
"Geometry.Height" 26.5mm
GATE 1 7 0
PEC11H-4220F-S0024
A1 0 U CHANNEL_1
B1 0 U CHANNEL_2
C1 0 U COMMON
S1 0 U S1
W1 0 U W1
MH1 0 U MH1
MH2 0 U MH2

*END*
*REMARK* SamacSys ECAD Model
12987153/1746203/2.50/7/3/Undefined or Miscellaneous
