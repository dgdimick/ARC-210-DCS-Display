# LeftSide Button PCB

This directory contains KiCad schematic and layout files for the leftside button panel.
