# Center Button PCB

This directory contains KiCad schematic and layout files for the center button panel.
